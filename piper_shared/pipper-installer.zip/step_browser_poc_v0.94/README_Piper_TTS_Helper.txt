Step Browser Piper TTS Helper (V0.94)
====================================

What this package does
----------------------
This package adds a local Piper narration helper for exported movies.
The HTML app stays the editor/export UI, and the helper generates real WAV
narration clips from each step's text field during the export preparation pass.

Included files
--------------
- Index_v0.94.html
- piper_tts_helper.py
- install_piper_tts_helper.bat
- start_piper_tts_helper.bat
- start_step_browser_local_server.bat
- log.txt

Recommended first-time setup
----------------------------
1. Run install_piper_tts_helper.bat
   - creates a Python virtual environment in this folder
   - installs piper-tts 1.4.1
   - downloads the default voice: en_US-lessac-high

2. Run start_piper_tts_helper.bat
   - starts the local helper at http://127.0.0.1:8765
   - keep this window open while exporting narrated video

3. Optional but recommended: run start_step_browser_local_server.bat
   - then open http://127.0.0.1:8080/Index_v0.94.html
   - this avoids extra browser weirdness from opening the HTML with file://

How to use narrated export
--------------------------
1. Put narration text in each step's text field.
2. Open the Export tab.
3. Leave "Include step text as narration audio in exported video" checked.
4. Make sure the helper URL is http://127.0.0.1:8765
5. Pick a Piper voice.
6. Start Export.

Important notes
---------------
- The first time you use a Piper voice that is not already downloaded, the helper
  may try to download it automatically into the voices folder.
- Narrated export still uses the two-pass flow:
  first it prepares narration audio for the export steps,
  then it records the movie with those audio clips mixed in.
- If the helper is reachable but export narration still fails, open this URL in your
  browser while the helper is running:
    http://127.0.0.1:8765/health
  That should return a small JSON status report.

Default local voice
-------------------
- en_US-lessac-high

Other voice ids you can try
---------------------------
- en_US-lessac-medium
- en_US-ryan-high
- en_US-ryan-medium
- en_US-libritts-high
- en_US-ljspeech-high
- en_GB-alan-medium

Sources used for this helper design
-----------------------------------
- Piper install and Python API docs: pip install piper-tts, download voices with
  python -m piper.download_voices, and synthesize with PiperVoice.synthesize_wav.
