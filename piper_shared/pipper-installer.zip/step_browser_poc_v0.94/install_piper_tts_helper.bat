@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

set "PYTHON_EXE="
where py >nul 2>nul
if %errorlevel%==0 set "PYTHON_EXE=py -3"
if not defined PYTHON_EXE (
  where python >nul 2>nul
  if %errorlevel%==0 set "PYTHON_EXE=python"
)
if not defined PYTHON_EXE (
  echo Python was not found on PATH.
  echo Install Python 3.9+ and try again.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  call %PYTHON_EXE% -m venv .venv
  if errorlevel 1 goto :fail
)

set "VENV_PY=.venv\Scripts\python.exe"

echo Upgrading pip...
call "%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 goto :fail

echo Installing Piper TTS...
call "%VENV_PY%" -m pip install piper-tts==1.4.1
if errorlevel 1 goto :fail

if not exist "voices" mkdir voices

echo Downloading default Piper voice en_US-lessac-high...
call "%VENV_PY%" -m piper.download_voices --data-dir "%cd%\voices" en_US-lessac-high
if errorlevel 1 (
  echo Failed to download the default voice automatically.
  echo You can still start the helper and let it try on first use, or download voices manually later.
)

echo.
echo Install complete.
echo Run start_piper_tts_helper.bat to launch the local narration helper.
pause
exit /b 0

:fail
echo.
echo Piper helper install failed.
pause
exit /b 1
